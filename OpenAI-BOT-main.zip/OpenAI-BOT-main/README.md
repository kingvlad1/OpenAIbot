# OpenAI-BOT

![](https://img.shields.io/github/languages/top/Sheudz/OpenAI-BOT?style=flat)
![](https://img.shields.io/github/languages/code-size/Sheudz/OpenAI-BOT?style=flat)

OpenAi discord bot

# Deployment
To deploy this bot, you must set nescesary environment variables, then run
```
docker compose up
```

# Requisites

- [Python](https://python.org)
- [Docker](https://docker.com)
